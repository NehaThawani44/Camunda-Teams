package com.example.camundaapi;

import java.io.*;
import com.squareup.okhttp.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/")
public class HelloServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/json");
        PrintWriter out = response.getWriter();
        //OkHttpClient client = new OkHttpClient().newBuilder().build();
        OkHttpClient client = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"client_id\": \"yRKIh2y2aUv_LFfrUsjkUyR.JMwHv6.9\",\r\n \"client_secret\":\"NiR4TPq6MWoD8-iBu-kjgVlsZ~9BYG2WcZfYb85ilgdtw0uHunkX_JjW65QAeLKv\",\r\n \"audience\":\"tasklist.camunda.io\",\r\n    \"grant_type\":\"client_credentials\"\r\n}");
        Request req = new Request.Builder()
                .url("https://bru-2.tasklist.camunda.io/e07602b8-2e35-47b0-b1c6-bd57f7d192a0/v1/tasks/search")
                .method("POST", body)
                .addHeader("content-type", "application/json")
                .addHeader("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlFVVXdPVFpDUTBVM01qZEVRME0wTkRFelJrUkJORFk0T0RZeE1FRTBSa1pFUlVWRVF6bERNZyJ9.eyJodHRwczovL2NhbXVuZGEuY29tL29yZ0lkIjoiMjI0MWU2MTEtMmRlNi00NDhlLTg3YzMtNGNlNzY1YmJjNjFlIiwiaXNzIjoiaHR0cHM6Ly93ZWJsb2dpbi5jbG91ZC5jYW11bmRhLmlvLyIsInN1YiI6Im13bzkwdDJyMzE2MDd6MzZCTkg2OXRXRktCWDU1ajFXQGNsaWVudHMiLCJhdWQiOiJ0YXNrbGlzdC5jYW11bmRhLmlvIiwiaWF0IjoxNjgzMDI1OTkyLCJleHAiOjE2ODMxMTIzOTIsImF6cCI6Im13bzkwdDJyMzE2MDd6MzZCTkg2OXRXRktCWDU1ajFXIiwic2NvcGUiOiJlMDc2MDJiOC0yZTM1LTQ3YjAtYjFjNi1iZDU3ZjdkMTkyYTAiLCJndHkiOiJjbGllbnQtY3JlZGVudGlhbHMifQ.dzBvm3SfLn37ZiW6URMbSTbUg455Gq4j0hSR7bVpBErcOVZUz9fdBBl13CA4Me0T9qvsLn31Nj6Q82MvZMFv2Ur5EmO8sWb5CK6gRc2MsVcbX_2zHfYy-1oB_HCfnrcEOrH2cbh6KFZndNy_qTOdTWwz3q6QzY4na57eywf4JdClF52a0QGlKUbtkytQuXnikmtyWgO5m-RZmroBKWGurrjB5HiHlw-YJnldSNz3Ou7caHGVWYtktWfyjnCrM3k0IxiGiy3KEtsgIbEfq9NiYjpasIoWO0oW_l-DK2uOYmkZkNA0_6L-4d3zmXKjp4ZLcHJDVJYwdbsIuYaj4yu9qw")
                .build();
        Response res = client.newCall(req).execute();
        String myJSON = res.body().string();
        out.write(myJSON);
    }

    public void destroy() {
    }
}