package com.example.camundaapi;

import java.io.*;
import com.squareup.okhttp.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/")
public class HelloServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/json");
        PrintWriter out = response.getWriter();
        //OkHttpClient client = new OkHttpClient().newBuilder().build();
        OkHttpClient client = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"client_id\": \"${client_id}\",\r\n \"client_secret\":\"{client-secret}\",\r\n \"audience\":\"tasklist.camunda.io\",\r\n    \"grant_type\":\"client_credentials\"\r\n}");
        Request req = new Request.Builder()
                .url("${CAMUNDA_TASKLIST_BASE_URL}/v1/tasks/search")
                .method("POST", body)
                .addHeader("content-type", "application/json")
                .addHeader("Authorization", "Bearer ${BearerToken}")
                .build();
        Response res = client.newCall(req).execute();
        String myJSON = res.body().string();
        out.write(myJSON);
    }

    public void destroy() {
    }
}